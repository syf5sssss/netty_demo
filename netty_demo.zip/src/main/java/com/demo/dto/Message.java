package com.demo.dto;

public class Message {
	
	public static final int TYPE = 0x88488848;
	public static final String S_Address = "D:\\NF\\Server";
	public static final String C_Address = "D:\\NF\\Client";
	
	public String type;
	public String filename;
	public String filelength;
	public String fileaddress;

}
