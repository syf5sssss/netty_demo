package com.demo.file.client;

public class RunClientDownTask extends Thread {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		super.run();
	}
	
	

}
