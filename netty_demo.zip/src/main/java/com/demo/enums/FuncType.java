package com.demo.enums;

public enum FuncType {
	
	File,
	Pojo,
	Beat;

}
