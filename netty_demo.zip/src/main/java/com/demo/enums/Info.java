package com.demo.enums;

public enum Info {

	Type,
	Priority,
	FileName,
	FileSize,
	Status;
	
}
