package com.demo.enums;

public enum Priority {

	Image,
	Office,
	File;
}
